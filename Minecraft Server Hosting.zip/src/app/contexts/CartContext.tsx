import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  details: string;
  config?: {
    ram: number;
    cpu: number;
    storage: number;
    players: number;
  };
}

interface CartContextType {
  cart: CartItem[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  totalPrice: number;
  subtotal: number;
  tax: number;
  total: number;
  taxRate: number;
  country: string;
  setCountry: (country: string) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

// VAT rates by country (for billing address reference only)
// Actual VAT is always 8.1% based on server location in St. Gallen, Switzerland
const VAT_RATES: { [key: string]: number } = {
  'CH': 0.081,  // Schweiz - 8.1%
  'DE': 0.19,   // Deutschland - 19%
  'AT': 0.20,   // Österreich - 20%
  'FR': 0.20,   // Frankreich - 20%
  'IT': 0.22,   // Italien - 22%
  'NL': 0.21,   // Niederlande - 21%
  'BE': 0.21,   // Belgien - 21%
  'LU': 0.17,   // Luxemburg - 17%
  'ES': 0.21,   // Spanien - 21%
  'PT': 0.23,   // Portugal - 23%
  'PL': 0.23,   // Polen - 23%
  'CZ': 0.21,   // Tschechien - 21%
  'HU': 0.27,   // Ungarn - 27%
  'SE': 0.25,   // Schweden - 25%
  'DK': 0.25,   // Dänemark - 25%
  'NO': 0.25,   // Norwegen - 25%
  'FI': 0.24,   // Finnland - 24%
  'GB': 0.20,   // Großbritannien - 20%
  'IE': 0.23,   // Irland - 23%
  'GR': 0.24,   // Griechenland - 24%
  'RO': 0.19,   // Rumänien - 19%
  'BG': 0.20,   // Bulgarien - 20%
  'HR': 0.25,   // Kroatien - 25%
  'SI': 0.22,   // Slowenien - 22%
  'SK': 0.20,   // Slowakei - 20%
  'LT': 0.21,   // Litauen - 21%
  'LV': 0.21,   // Lettland - 21%
  'EE': 0.20,   // Estland - 20%
  'US': 0.00,   // USA - No federal VAT
  'CA': 0.05,   // Kanada - GST 5%
  'AU': 0.10,   // Australien - GST 10%
  'NZ': 0.15,   // Neuseeland - GST 15%
  'JP': 0.10,   // Japan - Consumption Tax 10%
  'KR': 0.10,   // Südkorea - VAT 10%
  'SG': 0.08,   // Singapur - GST 8%
};

export function CartProvider({ children }: { children: ReactNode }) {
  // Load cart from localStorage on mount
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const savedCart = localStorage.getItem('blockhost_cart');
      return savedCart ? JSON.parse(savedCart) : [];
    } catch (error) {
      console.error('Error loading cart from localStorage:', error);
      return [];
    }
  });
  
  const [isCartOpen, setIsCartOpen] = useState(false);
  // Server location is always Switzerland (St. Gallen)
  const [country, setCountry] = useState('CH'); // Fixed to Switzerland based on server location

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('blockhost_cart', JSON.stringify(cart));
      // Dispatch custom event for cross-component synchronization
      window.dispatchEvent(new CustomEvent('cartUpdated', { detail: cart }));
    } catch (error) {
      console.error('Error saving cart to localStorage:', error);
    }
  }, [cart]);

  // Listen for cart updates from other components/contexts
  useEffect(() => {
    const handleCartUpdate = (event: CustomEvent) => {
      setCart(event.detail);
    };
    window.addEventListener('cartUpdated', handleCartUpdate as EventListener);
    return () => {
      window.removeEventListener('cartUpdated', handleCartUpdate as EventListener);
    };
  }, []);

  const addToCart = (item: CartItem) => {
    setCart([...cart, item]);
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const clearCart = () => {
    setCart([]);
  };

  const subtotal = cart.reduce((sum, item) => sum + item.price, 0);
  // Always use Swiss VAT (8.1%) since server is located in St. Gallen, Switzerland
  const taxRate = 0.081; // Swiss VAT 8.1%
  const tax = subtotal * taxRate;
  const total = subtotal + tax;
  const totalPrice = total; // Keep for backwards compatibility

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        clearCart,
        totalPrice,
        subtotal,
        tax,
        total,
        taxRate,
        country,
        setCountry,
        isCartOpen,
        setIsCartOpen,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}