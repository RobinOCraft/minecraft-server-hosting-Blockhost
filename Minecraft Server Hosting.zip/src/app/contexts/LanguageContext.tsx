import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'de' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  de: {
    // Navigation
    'nav.features': 'Features',
    'nav.pricing': 'Preise',
    'nav.locations': 'Standorte',
    'nav.signIn': 'Anmelden',
    'nav.getStarted': 'Jetzt starten',
    'nav.cart': 'Warenkorb',
    
    // Hero
    'hero.title': 'Premium Minecraft Server Hosting',
    'hero.subtitle': 'Starte deinen eigenen Minecraft Server in St. Gallen, Schweiz mit DDoS-Schutz von TCPShield',
    'hero.cta': 'Jetzt starten',
    'hero.learnMore': 'Mehr erfahren',
    
    // Features
    'features.title': 'Warum BlockHost wählen?',
    'features.subtitle': 'Alles was du brauchst für das perfekte Minecraft Server Hosting Erlebnis',
    'features.instant.title': 'Sofortige Einrichtung',
    'features.instant.desc': 'Dein Server ist in Sekunden bereit',
    'features.ddos.title': 'DDoS-Schutz',
    'features.ddos.desc': 'Geschützt von TCPShield',
    'features.support.title': '24/7 Support',
    'features.support.desc': 'Immer für dich da',
    'features.performance.title': 'Hohe Performance',
    'features.performance.desc': 'NVMe SSD Storage',
    'features.backups.title': 'Automatische Backups',
    'features.backups.desc': 'Deine Daten sind sicher',
    'features.panel.title': 'Modernes Panel',
    'features.panel.desc': 'Einfache Server-Verwaltung',
    
    // Stats
    'stats.servers': 'Aktive Server',
    'stats.uptime': 'Uptime',
    'stats.customers': 'Zufriedene Kunden',
    'stats.support': 'Support Response',
    
    // Pricing
    'pricing.title': 'Flexible Preispläne',
    'pricing.subtitle': 'Wähle den perfekten Plan für deine Bedürfnisse',
    'pricing.monthly': '/Monat',
    'pricing.basic': 'Basic',
    'pricing.pro': 'Pro',
    'pricing.premium': 'Premium',
    'pricing.enterprise': 'Enterprise',
    'pricing.mostPopular': 'Beliebteste',
    'pricing.custom': 'Individuell',
    'pricing.selectPlan': 'Plan wählen',
    'pricing.configure': 'Konfigurieren',
    'pricing.players': 'Spieler',
    'pricing.ram': 'RAM',
    'pricing.storage': 'Speicher',
    'pricing.backups': 'Backups',
    'pricing.support': 'Support',
    'pricing.daily': 'Täglich',
    'pricing.priority': 'Priorität',
    'pricing.dedicated': 'Dediziert',
    'pricing.customRam': 'Individueller RAM',
    'pricing.customStorage': 'Individueller Speicher',
    'pricing.customPlayers': 'Individuelle Spieleranzahl',
    
    // Server Locations
    'locations.title': 'Server Standort',
    'locations.subtitle': 'Premium Server in der Schweiz',
    'locations.stgallen': 'St. Gallen, Schweiz',
    'locations.latency': 'ms Latenz',
    'locations.status': 'Online',
    
    // Footer
    'footer.tagline': 'Premium Minecraft Server Hosting in der Schweiz',
    'footer.product': 'Produkt',
    'footer.features': 'Features',
    'footer.pricing': 'Preise',
    'footer.locations': 'Standorte',
    'footer.company': 'Unternehmen',
    'footer.about': 'Über uns',
    'footer.contact': 'Kontakt',
    'footer.support': 'Support',
    'footer.legal': 'Rechtliches',
    'footer.privacy': 'Datenschutz',
    'footer.terms': 'AGB',
    'footer.rights': 'Alle Rechte vorbehalten',
    
    // Cart
    'cart.title': 'Warenkorb',
    'cart.empty': 'Dein Warenkorb ist leer',
    'cart.emptyDesc': 'Füge einen Hosting-Plan hinzu um zu starten',
    'cart.browsePlans': 'Pläne durchsuchen',
    'cart.item': 'Artikel',
    'cart.items': 'Artikel',
    'cart.subtotal': 'Zwischensumme',
    'cart.tax': 'MwSt. (8.1%)',
    'cart.total': 'Gesamt',
    'cart.checkout': 'Zur Kasse',
    'cart.continueShopping': 'Weiter einkaufen',
    'cart.remove': 'Entfernen',
    'cart.addedToCart': 'Zum Warenkorb hinzugefügt',
    'cart.removedFromCart': 'Aus Warenkorb entfernt',
    
    // Modals
    'modal.signIn.title': 'Bei BlockHost anmelden',
    'modal.signIn.email': 'E-Mail',
    'modal.signIn.password': 'Passwort',
    'modal.signIn.remember': 'Angemeldet bleiben',
    'modal.signIn.forgot': 'Passwort vergessen?',
    'modal.signIn.button': 'Anmelden',
    'modal.signIn.noAccount': 'Noch kein Konto?',
    'modal.signIn.signUp': 'Registrieren',
    'modal.getStarted.title': 'Starte mit BlockHost',
    'modal.getStarted.name': 'Name',
    'modal.getStarted.email': 'E-Mail',
    'modal.getStarted.password': 'Passwort',
    'modal.getStarted.confirm': 'Passwort bestätigen',
    'modal.getStarted.terms': 'Ich akzeptiere die',
    'modal.getStarted.termsLink': 'AGB',
    'modal.getStarted.and': 'und',
    'modal.getStarted.privacy': 'Datenschutz',
    'modal.getStarted.button': 'Konto erstellen',
    'modal.getStarted.hasAccount': 'Bereits ein Konto?',
    'modal.getStarted.signIn': 'Anmelden',
    
    // Checkout
    'checkout.title': 'Kasse',
    'checkout.billing': 'Rechnungsinformationen',
    'checkout.payment': 'Zahlungsinformationen',
    'checkout.summary': 'Bestellübersicht',
    'checkout.firstName': 'Vorname',
    'checkout.lastName': 'Nachname',
    'checkout.email': 'E-Mail',
    'checkout.phone': 'Telefon',
    'checkout.company': 'Firma (optional)',
    'checkout.address': 'Adresse',
    'checkout.city': 'Stadt',
    'checkout.zip': 'PLZ',
    'checkout.country': 'Land',
    'checkout.switzerland': 'Schweiz',
    'checkout.germany': 'Deutschland',
    'checkout.austria': 'Österreich',
    'checkout.paymentMethod': 'Zahlungsmethode',
    'checkout.creditCard': 'Kreditkarte',
    'checkout.paypal': 'PayPal',
    'checkout.twint': 'TWINT',
    'checkout.applepay': 'Apple Pay',
    'checkout.invoice': 'Rechnung',
    'checkout.cardNumber': 'Kartennummer',
    'checkout.cardExpiry': 'Ablaufdatum (MM/JJ)',
    'checkout.cardCvc': 'CVC',
    'checkout.cardName': 'Name auf Karte',
    'checkout.termsAgree': 'Ich akzeptiere die',
    'checkout.termsLink': 'AGB',
    'checkout.and': 'und',
    'checkout.privacyLink': 'Datenschutzbestimmungen',
    'checkout.completeOrder': 'Bestellung abschließen',
    'checkout.secureCheckout': 'Sichere Zahlung',
    'checkout.backToCart': 'Zurück zum Warenkorb',
    'checkout.orderSuccess': 'Bestellung erfolgreich!',
    'checkout.orderError': 'Fehler bei der Bestellung',
    'checkout.processing': 'Verarbeite...',
    
    // Dashboard
    'dashboard.title': 'BlockHost Dashboard',
    'dashboard.welcome': 'Willkommen',
    'dashboard.home': 'Startseite',
    'dashboard.logout': 'Abmelden',
    'dashboard.cart': 'Warenkorb',
    
    // Dashboard Tabs
    'dashboard.overview': 'Übersicht',
    'dashboard.console': 'Konsole',
    'dashboard.files': 'Dateien',
    'dashboard.settings': 'Einstellungen',
    'dashboard.backups': 'Backups',
    'dashboard.billing': 'Rechnungen',
    
    // Server Info
    'dashboard.serverStatus': 'Server Status',
    'dashboard.status': 'Status',
    'dashboard.ipAddress': 'IP-Adresse',
    'dashboard.plan': 'Plan',
    'dashboard.online': 'Online',
    'dashboard.offline': 'Offline',
    'dashboard.starting': 'Startet...',
    'dashboard.stopping': 'Stoppt...',
    
    // Server Control
    'dashboard.serverName': 'Mein Minecraft Server',
    'dashboard.start': 'Start',
    'dashboard.stop': 'Stop',
    'dashboard.restart': 'Restart',
    'dashboard.players': 'Spieler',
    'dashboard.uptime': 'Uptime',
    'dashboard.ddosProtection': 'DDoS',
    
    // Resources
    'dashboard.cpuUsage': 'CPU Nutzung',
    'dashboard.ramUsage': 'RAM Nutzung',
    'dashboard.storageUsage': 'Storage Nutzung',
    'dashboard.current': 'Aktuell',
    
    // Quick Actions
    'dashboard.quickActions': 'Schnellzugriff',
    'dashboard.console.title': 'Server Konsole',
    'dashboard.console.description': 'Führen Sie Server-Befehle aus und überwachen Sie Logs',
    'dashboard.console.placeholder': 'Befehl eingeben...',
    'dashboard.console.execute': 'Ausführen',
    
    // File Manager
    'dashboard.files.title': 'Datei-Manager',
    'dashboard.files.description': 'Verwalten Sie Ihre Server-Dateien',
    'dashboard.files.upload': 'Datei hochladen',
    'dashboard.files.createFolder': 'Ordner erstellen',
    
    // Settings
    'dashboard.settings.title': 'Server Einstellungen',
    'dashboard.settings.description': 'Konfigurieren Sie Ihren Server',
    'dashboard.settings.serverName': 'Server Name',
    'dashboard.settings.motd': 'MOTD (Message of the Day)',
    'dashboard.settings.version': 'Minecraft Version',
    'dashboard.settings.autoUpdate': 'Automatische Updates',
    'dashboard.settings.autoUpdateDesc': 'Server wird automatisch aktualisiert, wenn neue Minecraft-Versionen verfügbar sind',
    'dashboard.settings.autoUpdateActive': 'Auto-Update ist aktiv. Ihr Server wird automatisch neugestartet, wenn neue Updates verfügbar sind.',
    'dashboard.settings.serverType': 'Server-Typ',
    'dashboard.settings.serverTypeDesc': 'Wählen Sie den Server-Typ, der Ihren Bedürfnissen am besten entspricht',
    'dashboard.settings.serverTypeSelected': 'ausgewählt',
    'dashboard.settings.gameMode': 'Spielmodus',
    'dashboard.settings.difficulty': 'Schwierigkeit',
    'dashboard.settings.hardcore': 'Hardcore',
    'dashboard.settings.hardcoreWarning': 'Hardcore: Permadeath aktiviert',
    'dashboard.settings.hardcoreNote': 'Bei Hardcore immer auf Hard gesetzt',
    'dashboard.settings.survival': 'Survival',
    'dashboard.settings.creative': 'Creative',
    'dashboard.settings.adventure': 'Adventure',
    'dashboard.settings.spectator': 'Spectator',
    'dashboard.settings.peaceful': 'Peaceful',
    'dashboard.settings.easy': 'Easy',
    'dashboard.settings.normal': 'Normal',
    'dashboard.settings.hard': 'Hard',
    'dashboard.settings.pvp': 'PvP aktivieren',
    'dashboard.settings.whitelist': 'Whitelist aktivieren',
    'dashboard.settings.save': 'Einstellungen speichern',
    
    // Server Types
    'dashboard.serverType.vanilla': 'Vanilla',
    'dashboard.serverType.vanillaDesc': 'Original Minecraft Server von Mojang',
    'dashboard.serverType.paper': 'Paper',
    'dashboard.serverType.paperDesc': 'Optimiert für Performance & Plugins',
    'dashboard.serverType.forge': 'Forge',
    'dashboard.serverType.forgeDesc': 'Klassisches Mod-Loading (1.7 - 1.20.1)',
    'dashboard.serverType.fabric': 'Fabric',
    'dashboard.serverType.fabricDesc': 'Modernes Mod-Loading (1.14+)',
    'dashboard.serverType.neoforge': 'NeoForge',
    'dashboard.serverType.neoforgeDesc': 'Nachfolger von Forge (1.20.2+)',
    'dashboard.serverType.quilt': 'Quilt',
    'dashboard.serverType.quiltDesc': 'Fork von Fabric (1.18+)',
    
    // Backups
    'dashboard.backups.title': 'Backups',
    'dashboard.backups.description': 'Verwalten Sie Ihre Server-Backups',
    'dashboard.backups.new': 'Neues Backup',
    'dashboard.backups.restore': 'Wiederherstellen',
    'dashboard.backups.download': 'Herunterladen',
    'dashboard.backups.delete': 'Löschen',
    'dashboard.backups.auto': 'Auto',
    'dashboard.backups.manual': 'Manuelles Backup',
    'dashboard.backups.daily': 'Daily Backups',
    'dashboard.backups.hourly': 'Hourly Backups',
    'dashboard.backups.realtime': 'Real-time Backups',
    'dashboard.backups.dailyDesc': 'Tägliche automatische Backups',
    'dashboard.backups.hourlyDesc': 'Stündliche automatische Backups',
    'dashboard.backups.realtimeDesc': 'Echtzeit-Backups mit sofortiger Synchronisation',
    'dashboard.backups.retention': 'Tage Aufbewahrung',
    'dashboard.backups.notAvailable': 'Manuelle Backups nicht verfügbar',
    'dashboard.backups.upgradeText': 'Upgraden Sie auf den Pro Plan für stündliche Backups und manuelle Backup-Erstellung, oder auf den Enterprise Plan für Echtzeit-Backups.',
    'dashboard.backups.upgrade': 'Jetzt upgraden',
    
    // Billing
    'dashboard.billing.currentPlan': 'Aktueller Plan',
    'dashboard.billing.month': '/Monat',
    'dashboard.billing.changePlan': 'Plan ändern',
    'dashboard.billing.invoices': 'Rechnungen',
    'dashboard.billing.invoice': 'Rechnung',
    'dashboard.billing.paid': 'Bezahlt',
    'dashboard.billing.pending': 'Ausstehend',
    
    // Payment Reminders
    'dashboard.paymentDueToday': '💳 Zahlungserinnerung: Ihre monatliche Zahlung von CHF {amount} ist heute fällig!',
    'dashboard.paymentOverdue': '⚠️ Zahlungserinnerung: Ihre Zahlung von CHF {amount} ist seit {days} überfällig!',
    'dashboard.paymentUpcoming': '📅 Zahlungserinnerung: Ihre nächste Zahlung von CHF {amount} ist in {days} fällig.',
    'dashboard.day': 'Tag',
    'dashboard.days': 'Tagen',
    
    // Toast Messages
    'toast.serverStarting': 'Server wird gestartet...',
    'toast.serverStopping': 'Server wird gestoppt...',
    'toast.serverRestarting': 'Server wird neugestartet...',
    'toast.serverStarted': 'Server gestartet',
    'toast.serverStopped': 'Server gestoppt',
    'toast.serverRestarted': 'Server neugestartet',
    'toast.commandExecuted': 'Befehl ausgeführt',
    'toast.autoUpdateEnabled': 'Auto-Update aktiviert',
    'toast.autoUpdateDisabled': 'Auto-Update deaktiviert',
    'toast.versionChanged': 'Minecraft Version auf {version} geändert',
    'toast.serverTypeChanged': 'Server-Typ auf {type} geändert',
    'toast.backupCreating': 'Manuelles Backup wird erstellt...',
    'toast.backupRestoring': 'Backup wird wiederhergestellt...',
    'toast.backupDownloading': 'Backup wird heruntergeladen...',
    'toast.backupDeleted': 'Backup gelöscht',
    'toast.planUpgrade': 'Plan-Upgrade wird vorbereitet...',
    
    // Active Subscription Alert
    'alert.hasActivePlan.title': 'Sie haben bereits ein aktives Abo',
    'alert.hasActivePlan.description': 'Sie haben bereits den {plan} Plan aktiv. Sie können Ihr Abo im Dashboard verwalten.',
    'alert.hasActivePlan.goToDashboard': 'Zum Dashboard',
    'alert.hasActivePlan.managePlan': 'Plan verwalten',
    
    // Payment Overdue Alert
    'alert.paymentOverdue.title': 'Zahlung überfällig',
    'alert.paymentOverdue.description': 'Ihre Zahlung für den {plan} Plan ist seit {days} Tagen überfällig. Bitte zahlen Sie jetzt, um eine Sperrung Ihres Servers zu vermeiden.',
    'alert.paymentOverdue.descriptionSingular': 'Ihre Zahlung für den {plan} Plan ist seit {days} Tag überfällig. Bitte zahlen Sie jetzt, um eine Sperrung Ihres Servers zu vermeiden.',
    'alert.paymentOverdue.payNow': 'Jetzt bezahlen',
    'alert.paymentOverdue.viewInvoice': 'Rechnung ansehen',
    'alert.paymentOverdue.dueDate': 'Fällig seit',
    'alert.paymentOverdue.warning': 'Warnung: Ihr Server wird nach {days} Tagen automatisch gesperrt.',
    'alert.paymentOverdue.warningSingular': 'Warnung: Ihr Server wird nach {days} Tag automatisch gesperrt.',
    'alert.paymentOverdue.reminder': 'Mahnung',
    'alert.paymentOverdue.finalWarning': 'Letzte Mahnung! Server-Sperrung in {days} Tagen.',
    'alert.paymentOverdue.finalWarningSingular': 'Letzte Mahnung! Server-Sperrung in {days} Tag.',
    
    // Payment Reminder (1-10 days)
    'alert.reminder.title': 'Zahlungserinnerung',
    'alert.reminder.description': 'Ihre Zahlung für den {plan} Plan ist seit {days} Tagen überfällig. Bitte zahlen Sie in den nächsten {remaining} Tagen, um eine Mahngebühr zu vermeiden.',
    'alert.reminder.descriptionSingular': 'Ihre Zahlung für den {plan} Plan ist seit {days} Tag überfällig. Bitte zahlen Sie in den nächsten {remaining} Tagen, um eine Mahngebühr zu vermeiden.',
    'alert.reminder.noFee': 'Noch keine Gebühren',
    'alert.reminder.nextStep': 'Nach Tag 10: 1. Mahnung mit CHF 10 Gebühr',
    
    // 1st Warning (11-20 days) - CHF 10
    'alert.warning1.title': '1. Mahnung',
    'alert.warning1.description': 'Ihre Zahlung ist seit {days} Tagen überfällig. Eine Mahngebühr von CHF 10 wurde zu Ihrer Rechnung hinzugefügt.',
    'alert.warning1.fee': 'Mahngebühr',
    'alert.warning1.nextStep': 'Nach Tag 20: 2. Mahnung mit zusätzlich CHF 20 Gebühr',
    'alert.warning1.totalDue': 'Gesamtbetrag fällig',
    
    // 2nd Warning (21-30 days) - CHF 20
    'alert.warning2.title': '2. Mahnung',
    'alert.warning2.description': 'Ihre Zahlung ist seit {days} Tagen überfällig. Eine weitere Mahngebühr von CHF 20 wurde hinzugefügt.',
    'alert.warning2.previousFees': 'Bisherige Gebühren',
    'alert.warning2.newFee': 'Neue Gebühr',
    'alert.warning2.nextStep': 'Nach Tag 30: 3. Mahnung mit zusätzlich CHF 30 Gebühr',
    
    // 3rd Warning (31-40 days) - CHF 30
    'alert.warning3.title': '3. Mahnung - Letzte Warnung',
    'alert.warning3.description': 'Ihre Zahlung ist seit {days} Tagen überfällig. Eine weitere Mahngebühr von CHF 30 wurde hinzugefügt. Dies ist Ihre letzte Warnung!',
    'alert.warning3.previousFees': 'Bisherige Gebühren',
    'alert.warning3.newFee': 'Neue Gebühr',
    'alert.warning3.critical': 'Kritisch: Nach Tag 40 wird Ihr Server automatisch gesperrt!',
    'alert.warning3.daysUntilSuspension': 'Tage bis zur Sperrung',
    
    // Server Suspended Alert
    'alert.serverSuspended.title': 'Server gesperrt',
    'alert.serverSuspended.description': 'Ihr Server wurde wegen ausstehender Zahlung gesperrt. Zahlen Sie jetzt, um Ihren Server sofort wieder zu aktivieren.',
    'alert.serverSuspended.suspendedSince': 'Gesperrt seit {days} Tagen',
    'alert.serverSuspended.suspendedSinceSingular': 'Gesperrt seit {days} Tag',
    'alert.serverSuspended.unlockNow': 'Jetzt freischalten',
    'alert.serverSuspended.contactSupport': 'Support kontaktieren',
    'alert.serverSuspended.warningDelete': 'Achtung: Nach 30 Tagen Sperrung werden alle Daten unwiderruflich gelöscht!',
    'alert.serverSuspended.totalFees': 'Gesamte Mahngebühren',
    
    // Dashboard - Additional Translations
    'dashboard.serverControl': 'Server-Steuerung',
    'dashboard.serverControl.quickAccess': 'Schnellzugriff auf Server-Befehle',
    'dashboard.fileManager': 'Datei-Manager',
    'dashboard.fileManager.description': 'Verwalten Sie Ihre Server-Dateien',
    'dashboard.fileManager.maxUpload': 'Maximale Upload-Größe',
    'dashboard.fileManager.perFile': 'pro Datei',
    'dashboard.fileManager.uploadRunning': 'Upload läuft...',
    'dashboard.fileManager.noFiles': 'Keine Dateien in diesem Verzeichnis',
    'dashboard.fileManager.noFilesDesc': 'Ordner erstellen oder Dateien hochladen',
    'dashboard.fileManager.uploading': 'Hochladen...',
    'dashboard.fileManager.back': 'Zurück',
    'dashboard.fileManager.open': 'Öffnen',
    'dashboard.fileManager.edit': 'Bearbeiten',
    'dashboard.fileManager.delete': 'Löschen',
    'dashboard.fileManager.download': 'Herunterladen',
    'dashboard.fileManager.newFolder': 'Neuen Ordner erstellen',
    'dashboard.fileManager.folderName': 'Ordnername',
    'dashboard.fileManager.folderPlaceholder': 'Mein Ordner...',
    'dashboard.fileManager.create': 'Erstellen',
    'dashboard.fileManager.cancel': 'Abbrechen',
    
    // Dashboard Settings
    'dashboard.settings.currency': 'Währung auswählen',
    'dashboard.settings.refreshRates': 'Kurse aktualisieren',
    'dashboard.settings.refreshing': 'Aktualisiere...',
    'dashboard.settings.nativeCurrency': 'Originalwährung - Keine Umrechnungsgebühren',
    'dashboard.settings.liveRate': 'Live-Kurs',
    'dashboard.settings.lastUpdated': 'Zuletzt aktualisiert',
    'dashboard.settings.maxPlayers': 'Maximale Spieleranzahl',
    'dashboard.settings.currentPlayers': 'Aktuell',
    'dashboard.settings.playersOnline': 'Spieler online',
    'dashboard.settings.performanceWarning': 'Performance-Warnung',
    'dashboard.settings.performanceWarningSuffix': 'werden max. {max} Spieler empfohlen',
    'dashboard.settings.renderDistance': 'Render-Distanz (Chunks)',
    'dashboard.settings.viewDistance': 'Blöcke Sichtweite',
    'dashboard.settings.recommendedMax': 'empfohlen',
    'dashboard.settings.playerWarning': 'Spieleranzahl-Warnung',
    'dashboard.settings.playerOptimal': 'Spieleranzahl optimal',
    'dashboard.settings.renderWarning': 'Render-Distanz-Warnung',
    'dashboard.settings.renderOptimal': 'Render-Distanz optimal',
    'dashboard.settings.saveSettings': 'Einstellungen speichern',
    'dashboard.settings.settingsSaved': 'Einstellungen gespeichert!',
    
    // Dashboard Console
    'dashboard.console.serverConsole': 'Server Konsole',
    'dashboard.console.serverConsoleDesc': 'Führen Sie Server-Befehle aus und überwachen Sie Logs (Tippen Sie \'help\' für alle Befehle)',
    'dashboard.console.commandPlaceholder': 'Befehl eingeben... (z.B. \'start\', \'help\', \'status\')',
    'dashboard.console.execute': 'Ausführen',
    
    // Dashboard Overview  
    'dashboard.overview.serverInfo': 'Server-Informationen',
    'dashboard.overview.serverControl': 'Server-Steuerung',
    'dashboard.overview.resourceUsage': 'Ressourcennutzung',
    'dashboard.overview.recentActivity': 'Letzte Aktivitäten',
    'dashboard.overview.connection': 'Verbindung',
    'dashboard.overview.connectionInfo': 'Server-Verbindungsinformationen',
    'dashboard.overview.serverAddress': 'Server-Adresse',
    'dashboard.overview.howToConnect': 'Wie verbinde ich mich?',
    'dashboard.overview.step': 'Schritt',
    'dashboard.overview.step1': 'Minecraft starten',
    'dashboard.overview.step2': 'Klicke auf "Multiplayer"',
    'dashboard.overview.step3': 'Klicke auf "Server hinzufügen"',
    'dashboard.overview.step4': 'Gib die Server-Adresse ein',
    'dashboard.overview.step5': 'Klicke auf "Fertig" und verbinde dich',
    'dashboard.overview.copyAddress': 'Adresse kopieren',
    'dashboard.overview.copied': 'Kopiert!',
    
    // Additional Toast Messages
    'toast.settingsSaved': 'Einstellungen gespeichert!',
    'toast.worldSaving': 'Speichere Welt...',
    'toast.worldSaved': 'Welt gespeichert',
    'toast.addressCopied': 'Adresse kopiert!',
    'toast.invalidCommand': 'Ungültiger Befehl',
    'toast.fileUploaded': 'Datei hochgeladen',
    'toast.fileDeleted': 'Datei gelöscht',
    'toast.folderCreated': 'Ordner erstellt',
    'toast.invalidChars': 'Ungültige Zeichen entfernt',
    'toast.invalidCharsError': 'Sonderzeichen wie / \\ : * ? " < > | sind nicht erlaubt',
  },
  en: {
    // Navigation
    'nav.features': 'Features',
    'nav.pricing': 'Pricing',
    'nav.locations': 'Locations',
    'nav.signIn': 'Sign In',
    'nav.getStarted': 'Get Started',
    'nav.cart': 'Cart',
    
    // Hero
    'hero.title': 'Premium Minecraft Server Hosting',
    'hero.subtitle': 'Launch your own Minecraft server in St. Gallen, Switzerland with DDoS protection from TCPShield',
    'hero.cta': 'Get Started',
    'hero.learnMore': 'Learn More',
    
    // Features
    'features.title': 'Why Choose BlockHost?',
    'features.subtitle': 'Everything you need for the perfect Minecraft server hosting experience',
    'features.instant.title': 'Instant Setup',
    'features.instant.desc': 'Your server ready in seconds',
    'features.ddos.title': 'DDoS Protection',
    'features.ddos.desc': 'Protected by TCPShield',
    'features.support.title': '24/7 Support',
    'features.support.desc': 'Always here for you',
    'features.performance.title': 'High Performance',
    'features.performance.desc': 'NVMe SSD Storage',
    'features.backups.title': 'Automatic Backups',
    'features.backups.desc': 'Your data is safe',
    'features.panel.title': 'Modern Panel',
    'features.panel.desc': 'Easy server management',
    
    // Stats
    'stats.servers': 'Active Servers',
    'stats.uptime': 'Uptime',
    'stats.customers': 'Happy Customers',
    'stats.support': 'Support Response',
    
    // Pricing
    'pricing.title': 'Flexible Pricing Plans',
    'pricing.subtitle': 'Choose the perfect plan for your needs',
    'pricing.monthly': '/month',
    'pricing.basic': 'Basic',
    'pricing.pro': 'Pro',
    'pricing.premium': 'Premium',
    'pricing.enterprise': 'Enterprise',
    'pricing.mostPopular': 'Most Popular',
    'pricing.custom': 'Custom',
    'pricing.selectPlan': 'Select Plan',
    'pricing.configure': 'Configure',
    'pricing.players': 'Players',
    'pricing.ram': 'RAM',
    'pricing.storage': 'Storage',
    'pricing.backups': 'Backups',
    'pricing.support': 'Support',
    'pricing.daily': 'Daily',
    'pricing.priority': 'Priority',
    'pricing.dedicated': 'Dedicated',
    'pricing.customRam': 'Custom RAM',
    'pricing.customStorage': 'Custom Storage',
    'pricing.customPlayers': 'Custom Players',
    
    // Server Locations
    'locations.title': 'Server Location',
    'locations.subtitle': 'Premium servers in Switzerland',
    'locations.stgallen': 'St. Gallen, Switzerland',
    'locations.latency': 'ms latency',
    'locations.status': 'Online',
    
    // Footer
    'footer.tagline': 'Premium Minecraft Server Hosting in Switzerland',
    'footer.product': 'Product',
    'footer.features': 'Features',
    'footer.pricing': 'Pricing',
    'footer.locations': 'Locations',
    'footer.company': 'Company',
    'footer.about': 'About',
    'footer.contact': 'Contact',
    'footer.support': 'Support',
    'footer.legal': 'Legal',
    'footer.privacy': 'Privacy',
    'footer.terms': 'Terms',
    'footer.rights': 'All rights reserved',
    
    // Cart
    'cart.title': 'Shopping Cart',
    'cart.empty': 'Your cart is empty',
    'cart.emptyDesc': 'Add a hosting plan to get started',
    'cart.browsePlans': 'Browse Plans',
    'cart.item': 'item',
    'cart.items': 'items',
    'cart.subtotal': 'Subtotal',
    'cart.tax': 'VAT (8.1%)',
    'cart.total': 'Total',
    'cart.checkout': 'Proceed to Checkout',
    'cart.continueShopping': 'Continue Shopping',
    'cart.remove': 'Remove',
    'cart.addedToCart': 'Added to cart',
    'cart.removedFromCart': 'Removed from cart',
    
    // Modals
    'modal.signIn.title': 'Sign in to BlockHost',
    'modal.signIn.email': 'Email',
    'modal.signIn.password': 'Password',
    'modal.signIn.remember': 'Remember me',
    'modal.signIn.forgot': 'Forgot password?',
    'modal.signIn.button': 'Sign In',
    'modal.signIn.noAccount': "Don't have an account?",
    'modal.signIn.signUp': 'Sign up',
    'modal.getStarted.title': 'Get Started with BlockHost',
    'modal.getStarted.name': 'Full Name',
    'modal.getStarted.email': 'Email',
    'modal.getStarted.password': 'Password',
    'modal.getStarted.confirm': 'Confirm Password',
    'modal.getStarted.terms': 'I agree to the',
    'modal.getStarted.termsLink': 'Terms of Service',
    'modal.getStarted.and': 'and',
    'modal.getStarted.privacy': 'Privacy Policy',
    'modal.getStarted.button': 'Create Account',
    'modal.getStarted.hasAccount': 'Already have an account?',
    'modal.getStarted.signIn': 'Sign in',
    
    // Checkout
    'checkout.title': 'Checkout',
    'checkout.billing': 'Billing Information',
    'checkout.payment': 'Payment Information',
    'checkout.summary': 'Order Summary',
    'checkout.firstName': 'First Name',
    'checkout.lastName': 'Last Name',
    'checkout.email': 'Email',
    'checkout.phone': 'Phone',
    'checkout.company': 'Company (optional)',
    'checkout.address': 'Address',
    'checkout.city': 'City',
    'checkout.zip': 'ZIP Code',
    'checkout.country': 'Country',
    'checkout.switzerland': 'Switzerland',
    'checkout.germany': 'Germany',
    'checkout.austria': 'Austria',
    'checkout.paymentMethod': 'Payment Method',
    'checkout.creditCard': 'Credit Card',
    'checkout.paypal': 'PayPal',
    'checkout.twint': 'TWINT',
    'checkout.applepay': 'Apple Pay',
    'checkout.invoice': 'Invoice',
    'checkout.cardNumber': 'Card Number',
    'checkout.cardExpiry': 'Expiry Date (MM/YY)',
    'checkout.cardCvc': 'CVC',
    'checkout.cardName': 'Name on Card',
    'checkout.termsAgree': 'I agree to the',
    'checkout.termsLink': 'Terms of Service',
    'checkout.and': 'and',
    'checkout.privacyLink': 'Privacy Policy',
    'checkout.completeOrder': 'Complete Order',
    'checkout.secureCheckout': 'Secure Checkout',
    'checkout.backToCart': 'Back to Cart',
    'checkout.orderSuccess': 'Order successful!',
    'checkout.orderError': 'Order failed',
    'checkout.processing': 'Processing...',
    
    // Dashboard
    'dashboard.title': 'BlockHost Dashboard',
    'dashboard.welcome': 'Welcome',
    'dashboard.home': 'Home',
    'dashboard.logout': 'Logout',
    'dashboard.cart': 'Cart',
    
    // Dashboard Tabs
    'dashboard.overview': 'Overview',
    'dashboard.console': 'Console',
    'dashboard.files': 'Files',
    'dashboard.settings': 'Settings',
    'dashboard.backups': 'Backups',
    'dashboard.billing': 'Billing',
    
    // Server Info
    'dashboard.serverStatus': 'Server Status',
    'dashboard.status': 'Status',
    'dashboard.ipAddress': 'IP Address',
    'dashboard.plan': 'Plan',
    'dashboard.online': 'Online',
    'dashboard.offline': 'Offline',
    'dashboard.starting': 'Starting...',
    'dashboard.stopping': 'Stopping...',
    
    // Server Control
    'dashboard.serverName': 'My Minecraft Server',
    'dashboard.start': 'Start',
    'dashboard.stop': 'Stop',
    'dashboard.restart': 'Restart',
    'dashboard.players': 'Players',
    'dashboard.uptime': 'Uptime',
    'dashboard.ddosProtection': 'DDoS',
    
    // Resources
    'dashboard.cpuUsage': 'CPU Usage',
    'dashboard.ramUsage': 'RAM Usage',
    'dashboard.storageUsage': 'Storage Usage',
    'dashboard.current': 'Current',
    
    // Quick Actions
    'dashboard.quickActions': 'Quick Actions',
    'dashboard.console.title': 'Server Console',
    'dashboard.console.description': 'Execute server commands and monitor logs',
    'dashboard.console.placeholder': 'Enter command...',
    'dashboard.console.execute': 'Execute',
    
    // File Manager
    'dashboard.files.title': 'File Manager',
    'dashboard.files.description': 'Manage your server files',
    'dashboard.files.upload': 'Upload File',
    'dashboard.files.createFolder': 'Create Folder',
    
    // Settings
    'dashboard.settings.title': 'Server Settings',
    'dashboard.settings.description': 'Configure your server',
    'dashboard.settings.serverName': 'Server Name',
    'dashboard.settings.motd': 'MOTD (Message of the Day)',
    'dashboard.settings.version': 'Minecraft Version',
    'dashboard.settings.autoUpdate': 'Automatic Updates',
    'dashboard.settings.autoUpdateDesc': 'Server will be automatically updated when new Minecraft versions are available',
    'dashboard.settings.autoUpdateActive': 'Auto-Update is active. Your server will be automatically restarted when new updates are available.',
    'dashboard.settings.serverType': 'Server Type',
    'dashboard.settings.serverTypeDesc': 'Choose the server type that best suits your needs',
    'dashboard.settings.serverTypeSelected': 'selected',
    'dashboard.settings.gameMode': 'Game Mode',
    'dashboard.settings.difficulty': 'Difficulty',
    'dashboard.settings.hardcore': 'Hardcore',
    'dashboard.settings.hardcoreWarning': 'Hardcore: Permadeath enabled',
    'dashboard.settings.hardcoreNote': 'Always set to Hard in Hardcore mode',
    'dashboard.settings.survival': 'Survival',
    'dashboard.settings.creative': 'Creative',
    'dashboard.settings.adventure': 'Adventure',
    'dashboard.settings.spectator': 'Spectator',
    'dashboard.settings.peaceful': 'Peaceful',
    'dashboard.settings.easy': 'Easy',
    'dashboard.settings.normal': 'Normal',
    'dashboard.settings.hard': 'Hard',
    'dashboard.settings.pvp': 'Enable PvP',
    'dashboard.settings.whitelist': 'Enable Whitelist',
    'dashboard.settings.save': 'Save Settings',
    
    // Server Types
    'dashboard.serverType.vanilla': 'Vanilla',
    'dashboard.serverType.vanillaDesc': 'Original Minecraft Server from Mojang',
    'dashboard.serverType.paper': 'Paper',
    'dashboard.serverType.paperDesc': 'Optimized for Performance & Plugins',
    'dashboard.serverType.forge': 'Forge',
    'dashboard.serverType.forgeDesc': 'Classic Mod-Loading (1.7 - 1.20.1)',
    'dashboard.serverType.fabric': 'Fabric',
    'dashboard.serverType.fabricDesc': 'Modern Mod-Loading (1.14+)',
    'dashboard.serverType.neoforge': 'NeoForge',
    'dashboard.serverType.neoforgeDesc': 'Successor of Forge (1.20.2+)',
    'dashboard.serverType.quilt': 'Quilt',
    'dashboard.serverType.quiltDesc': 'Fork of Fabric (1.18+)',
    
    // Backups
    'dashboard.backups.title': 'Backups',
    'dashboard.backups.description': 'Manage your server backups',
    'dashboard.backups.new': 'New Backup',
    'dashboard.backups.restore': 'Restore',
    'dashboard.backups.download': 'Download',
    'dashboard.backups.delete': 'Delete',
    'dashboard.backups.auto': 'Auto',
    'dashboard.backups.manual': 'Manual Backup',
    'dashboard.backups.daily': 'Daily Backups',
    'dashboard.backups.hourly': 'Hourly Backups',
    'dashboard.backups.realtime': 'Real-time Backups',
    'dashboard.backups.dailyDesc': 'Daily automatic backups',
    'dashboard.backups.hourlyDesc': 'Hourly automatic backups',
    'dashboard.backups.realtimeDesc': 'Real-time backups with instant synchronization',
    'dashboard.backups.retention': 'days retention',
    'dashboard.backups.notAvailable': 'Manual backups not available',
    'dashboard.backups.upgradeText': 'Upgrade to the Pro Plan for hourly backups and manual backup creation, or to the Enterprise Plan for real-time backups.',
    'dashboard.backups.upgrade': 'Upgrade now',
    
    // Billing
    'dashboard.billing.currentPlan': 'Current Plan',
    'dashboard.billing.month': '/month',
    'dashboard.billing.changePlan': 'Change Plan',
    'dashboard.billing.invoices': 'Invoices',
    'dashboard.billing.invoice': 'Invoice',
    'dashboard.billing.paid': 'Paid',
    'dashboard.billing.pending': 'Pending',
    
    // Payment Reminders
    'dashboard.paymentDueToday': '💳 Payment Reminder: Your monthly payment of CHF {amount} is due today!',
    'dashboard.paymentOverdue': '⚠️ Payment Reminder: Your payment of CHF {amount} is {days} overdue!',
    'dashboard.paymentUpcoming': '📅 Payment Reminder: Your next payment of CHF {amount} is due in {days}.',
    'dashboard.day': 'day',
    'dashboard.days': 'days',
    
    // Toast Messages
    'toast.serverStarting': 'Server is starting...',
    'toast.serverStopping': 'Server is stopping...',
    'toast.serverRestarting': 'Server is restarting...',
    'toast.serverStarted': 'Server started',
    'toast.serverStopped': 'Server stopped',
    'toast.serverRestarted': 'Server restarted',
    'toast.commandExecuted': 'Command executed',
    'toast.autoUpdateEnabled': 'Auto-Update enabled',
    'toast.autoUpdateDisabled': 'Auto-Update disabled',
    'toast.versionChanged': 'Minecraft version changed to {version}',
    'toast.serverTypeChanged': 'Server type changed to {type}',
    'toast.backupCreating': 'Creating manual backup...',
    'toast.backupRestoring': 'Restoring backup...',
    'toast.backupDownloading': 'Downloading backup...',
    'toast.backupDeleted': 'Backup deleted',
    'toast.planUpgrade': 'Preparing plan upgrade...',
    
    // Active Subscription Alert
    'alert.hasActivePlan.title': 'You already have an active subscription',
    'alert.hasActivePlan.description': 'You already have the {plan} plan active. You can manage your subscription in the dashboard.',
    'alert.hasActivePlan.goToDashboard': 'Go to Dashboard',
    'alert.hasActivePlan.managePlan': 'Manage Plan',
    
    // Payment Overdue Alert
    'alert.paymentOverdue.title': 'Payment Overdue',
    'alert.paymentOverdue.description': 'Your payment for the {plan} plan is {days} days overdue. Please pay now to avoid suspension of your server.',
    'alert.paymentOverdue.descriptionSingular': 'Your payment for the {plan} plan is {days} day overdue. Please pay now to avoid suspension of your server.',
    'alert.paymentOverdue.payNow': 'Pay Now',
    'alert.paymentOverdue.viewInvoice': 'View Invoice',
    'alert.paymentOverdue.dueDate': 'Due since',
    'alert.paymentOverdue.warning': 'Warning: Your server will be automatically suspended after {days} days.',
    'alert.paymentOverdue.warningSingular': 'Warning: Your server will be automatically suspended after {days} day.',
    'alert.paymentOverdue.reminder': 'Reminder',
    'alert.paymentOverdue.finalWarning': 'Final warning! Server suspension in {days} days.',
    'alert.paymentOverdue.finalWarningSingular': 'Final warning! Server suspension in {days} day.',
    
    // Payment Reminder (1-10 days)
    'alert.reminder.title': 'Payment Reminder',
    'alert.reminder.description': 'Your payment for the {plan} plan is {days} days overdue. Please pay within the next {remaining} days to avoid a reminder fee.',
    'alert.reminder.descriptionSingular': 'Your payment for the {plan} plan is {days} day overdue. Please pay within the next {remaining} days to avoid a reminder fee.',
    'alert.reminder.noFee': 'No fees yet',
    'alert.reminder.nextStep': 'After day 10: 1st warning with CHF 10 fee',
    
    // 1st Warning (11-20 days) - CHF 10
    'alert.warning1.title': '1st Warning',
    'alert.warning1.description': 'Your payment is {days} days overdue. A reminder fee of CHF 10 has been added to your invoice.',
    'alert.warning1.fee': 'Reminder Fee',
    'alert.warning1.nextStep': 'After day 20: 2nd warning with additional CHF 20 fee',
    'alert.warning1.totalDue': 'Total Amount Due',
    
    // 2nd Warning (21-30 days) - CHF 20
    'alert.warning2.title': '2nd Warning',
    'alert.warning2.description': 'Your payment is {days} days overdue. An additional reminder fee of CHF 20 has been added.',
    'alert.warning2.previousFees': 'Previous Fees',
    'alert.warning2.newFee': 'New Fee',
    'alert.warning2.nextStep': 'After day 30: 3rd warning with additional CHF 30 fee',
    
    // 3rd Warning (31-40 days) - CHF 30
    'alert.warning3.title': '3rd Warning - Final Notice',
    'alert.warning3.description': 'Your payment is {days} days overdue. An additional reminder fee of CHF 30 has been added. This is your final warning!',
    'alert.warning3.previousFees': 'Previous Fees',
    'alert.warning3.newFee': 'New Fee',
    'alert.warning3.critical': 'Critical: After day 40, your server will be automatically suspended!',
    'alert.warning3.daysUntilSuspension': 'Days until suspension',
    
    // Server Suspended Alert
    'alert.serverSuspended.title': 'Server Suspended',
    'alert.serverSuspended.description': 'Your server has been suspended due to outstanding payment. Pay now to reactivate your server immediately.',
    'alert.serverSuspended.suspendedSince': 'Suspended for {days} days',
    'alert.serverSuspended.suspendedSinceSingular': 'Suspended for {days} day',
    'alert.serverSuspended.unlockNow': 'Unlock Now',
    'alert.serverSuspended.contactSupport': 'Contact Support',
    'alert.serverSuspended.warningDelete': 'Warning: After 30 days of suspension, all data will be permanently deleted!',
    'alert.serverSuspended.totalFees': 'Total Reminder Fees',
    
    // Dashboard - Additional Translations
    'dashboard.serverControl': 'Server Control',
    'dashboard.serverControl.quickAccess': 'Quick Access to Server Commands',
    'dashboard.fileManager': 'File Manager',
    'dashboard.fileManager.description': 'Manage your server files',
    'dashboard.fileManager.maxUpload': 'Max Upload Size',
    'dashboard.fileManager.perFile': 'per file',
    'dashboard.fileManager.uploadRunning': 'Upload in progress...',
    'dashboard.fileManager.noFiles': 'No files in this directory',
    'dashboard.fileManager.noFilesDesc': 'Create a folder or upload files',
    'dashboard.fileManager.uploading': 'Uploading...',
    'dashboard.fileManager.back': 'Back',
    'dashboard.fileManager.open': 'Open',
    'dashboard.fileManager.edit': 'Edit',
    'dashboard.fileManager.delete': 'Delete',
    'dashboard.fileManager.download': 'Download',
    'dashboard.fileManager.newFolder': 'Create New Folder',
    'dashboard.fileManager.folderName': 'Folder Name',
    'dashboard.fileManager.folderPlaceholder': 'My Folder...',
    'dashboard.fileManager.create': 'Create',
    'dashboard.fileManager.cancel': 'Cancel',
    
    // Dashboard Settings
    'dashboard.settings.currency': 'Select Currency',
    'dashboard.settings.refreshRates': 'Refresh Rates',
    'dashboard.settings.refreshing': 'Refreshing...',
    'dashboard.settings.nativeCurrency': 'Native Currency - No Conversion Fees',
    'dashboard.settings.liveRate': 'Live Rate',
    'dashboard.settings.lastUpdated': 'Last Updated',
    'dashboard.settings.maxPlayers': 'Max Players',
    'dashboard.settings.currentPlayers': 'Current',
    'dashboard.settings.playersOnline': 'Players Online',
    'dashboard.settings.performanceWarning': 'Performance Warning',
    'dashboard.settings.performanceWarningSuffix': 'up to {max} players recommended',
    'dashboard.settings.renderDistance': 'Render Distance (Chunks)',
    'dashboard.settings.viewDistance': 'Block View Distance',
    'dashboard.settings.recommendedMax': 'recommended',
    'dashboard.settings.playerWarning': 'Player Count Warning',
    'dashboard.settings.playerOptimal': 'Optimal Player Count',
    'dashboard.settings.renderWarning': 'Render Distance Warning',
    'dashboard.settings.renderOptimal': 'Optimal Render Distance',
    'dashboard.settings.saveSettings': 'Save Settings',
    'dashboard.settings.settingsSaved': 'Settings saved!',
    
    // Dashboard Console
    'dashboard.console.serverConsole': 'Server Console',
    'dashboard.console.serverConsoleDesc': 'Execute server commands and monitor logs (type \'help\' for all commands)',
    'dashboard.console.commandPlaceholder': 'Enter command... (e.g. \'start\', \'help\', \'status\')',
    'dashboard.console.execute': 'Execute',
    
    // Dashboard Overview  
    'dashboard.overview.serverInfo': 'Server Info',
    'dashboard.overview.serverControl': 'Server Control',
    'dashboard.overview.resourceUsage': 'Resource Usage',
    'dashboard.overview.recentActivity': 'Recent Activity',
    'dashboard.overview.connection': 'Connection',
    'dashboard.overview.connectionInfo': 'Server Connection Info',
    'dashboard.overview.serverAddress': 'Server Address',
    'dashboard.overview.howToConnect': 'How do I connect?',
    'dashboard.overview.step': 'Step',
    'dashboard.overview.step1': 'Start Minecraft',
    'dashboard.overview.step2': 'Click "Multiplayer"',
    'dashboard.overview.step3': 'Click "Add Server"',
    'dashboard.overview.step4': 'Enter the server address',
    'dashboard.overview.step5': 'Click "Done" and connect',
    'dashboard.overview.copyAddress': 'Copy Address',
    'dashboard.overview.copied': 'Copied!',
    
    // Additional Toast Messages
    'toast.settingsSaved': 'Settings saved!',
    'toast.worldSaving': 'Saving world...',
    'toast.worldSaved': 'World saved',
    'toast.addressCopied': 'Address copied!',
    'toast.invalidCommand': 'Invalid command',
    'toast.fileUploaded': 'File uploaded',
    'toast.fileDeleted': 'File deleted',
    'toast.folderCreated': 'Folder created',
    'toast.invalidChars': 'Invalid characters removed',
    'toast.invalidCharsError': 'Special characters like / \\ : * ? " < > | are not allowed',
  }
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  // Load language from localStorage or default to 'de'
  const [language, setLanguage] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('blockhost_language');
      return (saved === 'en' || saved === 'de') ? saved : 'de';
    }
    return 'de';
  });

  // Save language to localStorage whenever it changes
  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('blockhost_language', lang);
    }
  };

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['de']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    // Fallback for development hot-reload issues - silently return defaults
    return {
      language: 'de' as Language,
      setLanguage: () => {},
      t: (key: string) => key,
    };
  }
  return context;
}