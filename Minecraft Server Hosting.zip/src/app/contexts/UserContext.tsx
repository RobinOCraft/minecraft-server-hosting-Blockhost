import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';

// User Context for authentication and user management
type PaymentStatus = 'active' | 'reminder' | 'warning1' | 'warning2' | 'warning3' | 'suspended';

export interface PlanConfig {
  ram: number;
  cpu: number;
  storage: number;
}

interface User {
  name: string;
  email: string;
  username?: string;
  isAdmin?: boolean;
  isOwner?: boolean;
  hasActivePlan?: boolean;
  currentPlan?: 'Basic' | 'Pro' | 'Premium' | 'Enterprise';
  planConfig?: PlanConfig;
  paymentStatus?: PaymentStatus;
  nextPaymentDate?: Date;
  daysOverdue?: number;
  warningFees?: number;
}

interface RegisteredUser {
  name: string;
  email: string;
  password: string;
  username?: string;
  currentPlan?: 'Basic' | 'Pro' | 'Premium' | 'Enterprise';
  planConfig?: PlanConfig;
  hasActivePlan?: boolean;
  paymentStatus?: PaymentStatus;
  nextPaymentDate?: string;
  daysOverdue?: number;
  warningFees?: number;
}

interface UserContextType {
  user: User | null;
  isLoggedIn: boolean;
  login: (email: string, password: string) => boolean;
  register: (name: string, email: string, password: string) => boolean;
  logout: () => void;
  updateUserPlan: (plan: 'Basic' | 'Pro' | 'Premium' | 'Enterprise', config?: PlanConfig) => void;
  resetPassword: (email: string, newPassword: string) => boolean;
  checkEmailExists: (email: string) => boolean;
  checkNameExists: (name: string) => boolean;
  pendingVerification: { email: string; password: string; code: string } | null;
  verifyEmail: (code: string) => boolean;
  cancelVerification: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);
UserContext.displayName = 'UserContext';

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    // Restore user from localStorage on initial load
    if (typeof window === 'undefined') return null;
    try {
      const storedUser = localStorage.getItem('blockhost_current_user');
      if (storedUser) {
        const parsedUser = JSON.parse(storedUser);
        // Convert date strings back to Date objects
        if (parsedUser.nextPaymentDate) {
          parsedUser.nextPaymentDate = new Date(parsedUser.nextPaymentDate);
        }
        return parsedUser;
      }
      return null;
    } catch (error) {
      console.error('Failed to load current user:', error);
      return null;
    }
  });
  
  const [registeredUsers, setRegisteredUsers] = useState<Map<string, RegisteredUser>>(() => {
    if (typeof window === 'undefined') return new Map();
    try {
      const stored = localStorage.getItem('blockhost_registered_users');
      if (stored) {
        const usersArray = JSON.parse(stored);
        const usersMap = new Map(usersArray.map((u: RegisteredUser) => [u.email.toLowerCase(), u]));
        
        // Ensure owner account always exists
        if (!usersMap.has('robinmoser14@gmail.com')) {
          usersMap.set('robinmoser14@gmail.com', {
            email: 'robinmoser14@gmail.com',
            username: 'RobinOCraft1',
            password: 'BlockHost2025',
            name: 'Robin Moser',
            hasActivePlan: true,
            currentPlan: 'Enterprise'
          });
        }
        
        // Ensure admin account always exists
        if (!usersMap.has('moserkevin13@gmail.com')) {
          usersMap.set('moserkevin13@gmail.com', {
            email: 'moserkevin13@gmail.com',
            username: 'KevinECraft',
            password: 'BlockHostadmin',
            name: 'Kevin Moser',
            hasActivePlan: true,
            currentPlan: 'Enterprise'
          });
        }
        
        return usersMap;
      }
      
      // Initialize with owner and admin accounts if no stored data
      const initialMap = new Map<string, RegisteredUser>();
      initialMap.set('robinmoser14@gmail.com', {
        email: 'robinmoser14@gmail.com',
        username: 'RobinOCraft1',
        password: 'BlockHost2025',
        name: 'Robin Moser',
        hasActivePlan: true,
        currentPlan: 'Enterprise'
      });
      initialMap.set('moserkevin13@gmail.com', {
        email: 'moserkevin13@gmail.com',
        username: 'KevinECraft',
        password: 'BlockHostadmin',
        name: 'Kevin Moser',
        hasActivePlan: true,
        currentPlan: 'Enterprise'
      });
      
      return initialMap;
    } catch (error) {
      console.error('Failed to load registered users:', error);
      
      // Even on error, return map with owner and admin accounts
      const errorMap = new Map<string, RegisteredUser>();
      errorMap.set('robinmoser14@gmail.com', {
        email: 'robinmoser14@gmail.com',
        username: 'RobinOCraft1',
        password: 'BlockHost2025',
        name: 'Robin Moser',
        hasActivePlan: true,
        currentPlan: 'Enterprise'
      });
      errorMap.set('moserkevin13@gmail.com', {
        email: 'moserkevin13@gmail.com',
        username: 'KevinECraft',
        password: 'BlockHostadmin',
        name: 'Kevin Moser',
        hasActivePlan: true,
        currentPlan: 'Enterprise'
      });
      
      return errorMap;
    }
  });

  // Save current user to localStorage whenever it changes
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      if (user) {
        localStorage.setItem('blockhost_current_user', JSON.stringify(user));
      } else {
        localStorage.removeItem('blockhost_current_user');
      }
    } catch (error) {
      console.error('Failed to save current user:', error);
    }
  }, [user]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const usersArray = Array.from(registeredUsers.values());
      localStorage.setItem('blockhost_registered_users', JSON.stringify(usersArray));
    } catch (error) {
      console.error('Failed to save registered users:', error);
    }
  }, [registeredUsers]);

  const [pendingVerification, setPendingVerification] = useState<{ email: string; password: string; code: string } | null>(null);

  const login = (email: string, password: string): boolean => {
    const registeredUser = registeredUsers.get(email.toLowerCase());
    
    if (!registeredUser) {
      return false;
    }
    
    if (registeredUser.password !== password) {
      return false;
    }
    
    // Generate 6-digit verification code
    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Set pending verification
    setPendingVerification({
      email: email.toLowerCase(),
      password,
      code: verificationCode
    });
    
    return true;
  };

  const verifyEmail = (code: string): boolean => {
    if (!pendingVerification || pendingVerification.code !== code) {
      return false;
    }
    
    const { email, password } = pendingVerification;
    const registeredUser = registeredUsers.get(email);
    
    if (!registeredUser) {
      setPendingVerification(null);
      return false;
    }
    
    // Check if user is admin
    const isOwner = email === 'robinmoser14@gmail.com';
    const isAdmin = email === 'moserkevin13@gmail.com';
    
    // Use stored plan data if available, otherwise use random for demo
    const hasActivePlan = registeredUser.hasActivePlan ?? (Math.random() > 0.7);
    const currentPlan = registeredUser.currentPlan ?? (hasActivePlan ? (['Basic', 'Pro', 'Premium', 'Enterprise'][Math.floor(Math.random() * 4)] as any) : undefined);
    const planConfig = registeredUser.planConfig;
    
    let paymentStatus: PaymentStatus = registeredUser.paymentStatus ?? 'active';
    let daysOverdue = registeredUser.daysOverdue ?? 0;
    let warningFees = registeredUser.warningFees ?? 0;
    
    // Only generate random payment status if no stored status exists
    if (!registeredUser.paymentStatus && hasActivePlan) {
      const random = Math.random();
      
      if (random > 0.9) {
        paymentStatus = 'suspended';
        daysOverdue = 40 + Math.floor(Math.random() * 10);
        warningFees = 60;
      } else if (random > 0.75) {
        paymentStatus = 'warning3';
        daysOverdue = 31 + Math.floor(Math.random() * 9);
        warningFees = 30;
      } else if (random > 0.6) {
        paymentStatus = 'warning2';
        daysOverdue = 21 + Math.floor(Math.random() * 9);
        warningFees = 10;
      } else if (random > 0.45) {
        paymentStatus = 'warning1';
        daysOverdue = 11 + Math.floor(Math.random() * 9);
        warningFees = 0;
      } else if (random > 0.3) {
        paymentStatus = 'reminder';
        daysOverdue = 1 + Math.floor(Math.random() * 9);
        warningFees = 0;
      }
    }
    
    const nextPaymentDate = registeredUser.nextPaymentDate 
      ? new Date(registeredUser.nextPaymentDate)
      : (() => {
          const date = new Date();
          if (daysOverdue > 0) {
            date.setDate(date.getDate() - daysOverdue);
          } else {
            date.setDate(date.getDate() + 30);
          }
          return date;
        })();
    
    const username = registeredUser.username || registeredUser.name.split(' ')[0].charAt(0).toUpperCase() + registeredUser.name.split(' ')[0].slice(1);
    
    setUser({ 
      name: registeredUser.name, 
      email: registeredUser.email, 
      username,
      isAdmin,
      isOwner,
      hasActivePlan,
      currentPlan,
      planConfig,
      paymentStatus,
      nextPaymentDate,
      daysOverdue,
      warningFees
    });
    
    setPendingVerification(null);
    return true;
  };

  const cancelVerification = () => {
    setPendingVerification(null);
  };

  const register = (name: string, email: string, password: string): boolean => {
    // Check if email already exists
    if (registeredUsers.has(email.toLowerCase())) {
      return false;
    }
    
    // Check if name already exists (case-insensitive)
    const nameExists = Array.from(registeredUsers.values()).some(
      user => user.name.toLowerCase() === name.toLowerCase()
    );
    
    if (nameExists) {
      return false;
    }
    
    const newUser: RegisteredUser = {
      name,
      email: email.toLowerCase(),
      password
    };
    
    const updatedUsers = new Map(registeredUsers);
    updatedUsers.set(email.toLowerCase(), newUser);
    setRegisteredUsers(updatedUsers);
    
    // Check if user is admin
    const isAdmin = email.toLowerCase() === 'moserkevin13@gmail.com';
    
    const username = name.split(' ')[0].charAt(0).toUpperCase() + name.split(' ')[0].slice(1);
    setUser({ 
      name, 
      email, 
      username,
      isAdmin,
      isOwner: email.toLowerCase() === 'robinmoser14@gmail.com',
      hasActivePlan: false,
      paymentStatus: 'active',
      warningFees: 0
    });
    
    return true;
  };

  const logout = () => {
    setUser(null);
  };

  const updateUserPlan = (plan: 'Basic' | 'Pro' | 'Premium' | 'Enterprise', config?: PlanConfig) => {
    if (user) {
      const nextPaymentDate = new Date();
      nextPaymentDate.setDate(nextPaymentDate.getDate() + 30);
      
      const updatedUser = {
        ...user,
        hasActivePlan: true,
        currentPlan: plan,
        planConfig: config,
        paymentStatus: 'active' as PaymentStatus,
        nextPaymentDate,
        daysOverdue: 0,
        warningFees: 0
      };
      
      setUser(updatedUser);
      
      // Also update the registered user data to persist the plan
      const registeredUser = registeredUsers.get(user.email.toLowerCase());
      if (registeredUser) {
        const updatedUsers = new Map(registeredUsers);
        updatedUsers.set(user.email.toLowerCase(), {
          ...registeredUser,
          currentPlan: plan,
          planConfig: config,
          hasActivePlan: true,
          paymentStatus: 'active',
          nextPaymentDate: nextPaymentDate.toISOString(),
          daysOverdue: 0,
          warningFees: 0
        });
        setRegisteredUsers(updatedUsers);
      }
    }
  };

  const resetPassword = (email: string, newPassword: string): boolean => {
    const registeredUser = registeredUsers.get(email.toLowerCase());
    
    if (!registeredUser) {
      return false;
    }
    
    // Create new Map and update user with new password (old password is replaced)
    const updatedUsers = new Map(registeredUsers);
    updatedUsers.set(email.toLowerCase(), { 
      ...registeredUser, 
      password: newPassword  // This replaces the old password completely
    });
    setRegisteredUsers(updatedUsers);
    
    return true;
  };

  const checkEmailExists = (email: string): boolean => {
    return registeredUsers.has(email.toLowerCase());
  };

  const checkNameExists = (name: string): boolean => {
    return Array.from(registeredUsers.values()).some(
      user => user.name.toLowerCase() === name.toLowerCase()
    );
  };

  return (
    <UserContext.Provider 
      value={{ 
        user, 
        isLoggedIn: !!user, 
        login, 
        register, 
        logout,
        updateUserPlan,
        resetPassword,
        checkEmailExists,
        checkNameExists,
        pendingVerification,
        verifyEmail,
        cancelVerification
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within UserProvider');
  }
  return context;
}