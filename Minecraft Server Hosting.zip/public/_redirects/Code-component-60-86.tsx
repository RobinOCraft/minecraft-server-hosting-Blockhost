# Redirect www to non-www (optional - entfernen falls nicht gewünscht)
https://www.blockhosts.org/* https://blockhosts.org/:splat 301!

# SPA Routing - alle Routen zu index.html
/*    /index.html   200
